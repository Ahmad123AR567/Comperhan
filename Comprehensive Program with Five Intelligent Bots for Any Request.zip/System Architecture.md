## System Architecture

The application will be a web-based platform with a clear separation between the frontend (user interface) and the backend (bot logic and data processing).

**Frontend:**
*   **Technology:** React.js for a dynamic and interactive user experience.
*   **Styling:** Modern CSS framework (e.g., Tailwind CSS or Material-UI) for an attractive and elegant interface with nice buttons and a layered request display.
*   **Communication:** RESTful API calls to the backend.

**Backend:**
*   **Technology:** Python with Flask for a lightweight and flexible web framework.
*   **Bot Orchestration:** A central orchestrator module to manage bot interactions and workflow.
*   **Communication:** Internal messaging queue (e.g., RabbitMQ or Redis Pub/Sub) for inter-bot communication.
*   **Data Storage:** A database (e.g., PostgreSQL or MongoDB) to store user requests, project progress, and bot-generated data.

## Bot Specifications

**1. Coordinator Bot (Frontend-facing & Backend Orchestrator)**
*   **Mission:** Direct interaction with the user, receiving requests, distributing tasks to other bots, and delivering the final project.
*   **Responsibilities:**
    *   User authentication and session management.
    *   Request parsing and validation.
    *   Workflow management: initiating, monitoring, and controlling the project lifecycle.
    *   Presenting real-time project status updates to the user.
    *   Aggregating results from other bots and formatting the final deliverable.
    *   Handling user feedback and potential re-runs of specific bot tasks.

**2. Research Bot (Backend - Background Worker)**
*   **Mission:** Deep search from all available sources (internet, databases, knowledge bases) regarding the user request.
*   **Responsibilities:**
    *   Receiving search queries from the Coordinator Bot.
    *   Utilizing web search APIs (e.g., Google Search API, custom scrapers).
    *   Accessing specialized databases or knowledge graphs if required.
    *   Filtering and prioritizing search results based on relevance and credibility.
    *   Storing raw search results for the Analysis Bot.

**3. Analysis Bot (Backend - Background Worker)**
*   **Mission:** Collect all searching results from the Research Bot, prepare a comprehensive recap/full correct conclusion for the project, and outline how it should be built.
*   **Responsibilities:**
    *   Retrieving raw search data from storage.
    *   Natural Language Processing (NLP) for information extraction and summarization.
    *   Synthesizing information from diverse sources to form a coherent understanding.
    *   Identifying key requirements, constraints, and potential solutions for the project.
    *   Generating a structured project plan or blueprint for the Builder Bot.
    *   Flagging any ambiguities or missing information that require further research.

**4. Builder Bot (Backend - Background Worker)**
*   **Mission:** Fully build the comprehensive project from A to Z based on the data prepared by other bots, especially the Analysis Bot.
*   **Responsibilities:**
    *   Receiving the project blueprint from the Analysis Bot.
    *   Interpreting detailed instructions and specifications.
    *   Utilizing various tools and APIs for project creation (e.g., code generation, content creation, design tools, data manipulation libraries).
    *   Iterative building process, potentially requesting clarifications from the Analysis Bot.
    *   Generating intermediate and final project assets.
    *   Ensuring adherence to the project plan and quality standards.

**5. Audit Bot (Backend - Background Worker)**
*   **Mission:** Fully audit the final product, check for improvements, perform marketing analysis if needed, and prepare a full report before delivering to the Coordinator Bot.
*   **Responsibilities:**
    *   Receiving the built project from the Builder Bot.
    *   Performing quality assurance checks (e.g., code review, content accuracy, functionality testing).
    *   Identifying areas for improvement or optimization.
    *   Conducting marketing analysis (e.g., market trends, target audience, competitive landscape) if requested.
    *   Generating a comprehensive audit report, including recommendations and marketing insights.
    *   Packaging the final project and the audit report for delivery to the Coordinator Bot.

## Communication Flow

1.  **User to Coordinator Bot:** User submits a request via the frontend.
2.  **Coordinator Bot to Research Bot:** Coordinator Bot sends initial query to Research Bot.
3.  **Research Bot to Data Storage:** Research Bot saves raw search results.
4.  **Coordinator Bot to Analysis Bot:** Coordinator Bot triggers Analysis Bot after Research Bot completes.
5.  **Analysis Bot to Data Storage:** Analysis Bot reads raw search results and saves processed data/project blueprint.
6.  **Coordinator Bot to Builder Bot:** Coordinator Bot triggers Builder Bot after Analysis Bot completes.
7.  **Builder Bot to Data Storage:** Builder Bot saves built project assets.
8.  **Coordinator Bot to Audit Bot:** Coordinator Bot triggers Audit Bot after Builder Bot completes.
9.  **Audit Bot to Data Storage:** Audit Bot saves audit report and final packaged project.
10. **Audit Bot to Coordinator Bot:** Audit Bot signals completion to Coordinator Bot.
11. **Coordinator Bot to User:** Coordinator Bot presents the final project and report to the user via the frontend.


