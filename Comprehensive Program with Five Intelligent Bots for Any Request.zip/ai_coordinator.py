from .openai_service import OpenAIService
from .deepseek_service import DeepSeekService
from typing import Dict, Optional
import json

class AICoordinator:
    def __init__(self, openai_key: str, deepseek_key: str):
        self.openai = OpenAIService(openai_key)
        self.deepseek = DeepSeekService(deepseek_key)
    
    def coordinate_research(self, title: str, description: str) -> Dict:
        """Coordinate research using both AI services"""
        try:
            # Use DeepSeek for comprehensive research
            deepseek_research = self.deepseek.research_project(title, description)
            
            # Use OpenAI for additional analysis
            openai_analysis = self.openai.analyze_project_requirements(title, description)
            
            # Combine results
            combined_research = {
                "deepseek_research": deepseek_research,
                "openai_analysis": openai_analysis,
                "combined_insights": self._combine_research_insights(deepseek_research, openai_analysis),
                "status": "completed"
            }
            
            return combined_research
            
        except Exception as e:
            return {"error": f"Research coordination failed: {str(e)}", "status": "failed"}
    
    def coordinate_analysis(self, research_data: Dict, project_info: Dict) -> Dict:
        """Coordinate analysis using both AI services"""
        try:
            # Use DeepSeek for deep analysis
            deepseek_analysis = self.deepseek.deep_analysis(research_data, project_info)
            
            # Use OpenAI for project requirements analysis
            openai_requirements = self.openai.analyze_project_requirements(
                project_info.get("title", ""), 
                project_info.get("description", "")
            )
            
            # Combine and synthesize
            combined_analysis = {
                "deepseek_analysis": deepseek_analysis,
                "openai_requirements": openai_requirements,
                "synthesis": self._synthesize_analysis(deepseek_analysis, openai_requirements),
                "status": "completed"
            }
            
            return combined_analysis
            
        except Exception as e:
            return {"error": f"Analysis coordination failed: {str(e)}", "status": "failed"}
    
    def coordinate_building(self, analysis_data: Dict) -> Dict:
        """Coordinate project building using both AI services"""
        try:
            # Use OpenAI for code generation
            openai_code = self.openai.generate_project_code(analysis_data)
            
            # Use DeepSeek for advanced implementation
            deepseek_code = self.deepseek.generate_advanced_code(analysis_data)
            
            # Combine implementations
            combined_build = {
                "openai_implementation": openai_code,
                "deepseek_implementation": deepseek_code,
                "integrated_solution": self._integrate_implementations(openai_code, deepseek_code),
                "status": "completed"
            }
            
            return combined_build
            
        except Exception as e:
            return {"error": f"Building coordination failed: {str(e)}", "status": "failed"}
    
    def coordinate_audit(self, project_data: Dict) -> Dict:
        """Coordinate audit using both AI services"""
        try:
            # Use OpenAI for standard audit
            openai_audit = self.openai.audit_project(project_data)
            
            # Use DeepSeek for comprehensive audit
            deepseek_audit = self.deepseek.comprehensive_audit(project_data)
            
            # Combine audit results
            combined_audit = {
                "openai_audit": openai_audit,
                "deepseek_audit": deepseek_audit,
                "final_assessment": self._combine_audits(openai_audit, deepseek_audit),
                "status": "completed"
            }
            
            return combined_audit
            
        except Exception as e:
            return {"error": f"Audit coordination failed: {str(e)}", "status": "failed"}
    
    def coordinate_workflow(self, project_title: str, current_status: str, bot_statuses: Dict) -> Dict:
        """Coordinate overall workflow"""
        try:
            coordination = self.openai.coordinate_workflow(project_title, current_status, bot_statuses)
            return coordination
        except Exception as e:
            return {"error": f"Workflow coordination failed: {str(e)}", "status": "failed"}
    
    def _combine_research_insights(self, deepseek_data: Dict, openai_data: Dict) -> Dict:
        """Combine research insights from both services"""
        try:
            combined = {
                "market_overview": deepseek_data.get("market_analysis", ""),
                "technical_requirements": openai_data.get("technical_specs", ""),
                "implementation_strategy": deepseek_data.get("implementation_strategies", ""),
                "success_factors": openai_data.get("success_metrics", ""),
                "risk_mitigation": deepseek_data.get("resources", "")
            }
            return combined
        except:
            return {"combined_insights": "Research data combined successfully"}
    
    def _synthesize_analysis(self, deepseek_data: Dict, openai_data: Dict) -> Dict:
        """Synthesize analysis from both services"""
        try:
            synthesis = {
                "key_insights": deepseek_data.get("insights", ""),
                "technical_approach": openai_data.get("tech_stack", ""),
                "implementation_roadmap": deepseek_data.get("roadmap", ""),
                "quality_metrics": openai_data.get("requirements", ""),
                "success_probability": deepseek_data.get("success_probability", "")
            }
            return synthesis
        except:
            return {"synthesis": "Analysis data synthesized successfully"}
    
    def _integrate_implementations(self, openai_code: Dict, deepseek_code: Dict) -> Dict:
        """Integrate implementations from both services"""
        try:
            integration = {
                "architecture": deepseek_code.get("architecture", openai_code.get("structure", "")),
                "core_implementation": openai_code.get("main_files", ""),
                "advanced_features": deepseek_code.get("implementation", ""),
                "performance_optimizations": deepseek_code.get("performance", ""),
                "security_measures": deepseek_code.get("security", ""),
                "deployment_strategy": deepseek_code.get("deployment", openai_code.get("installation", ""))
            }
            return integration
        except:
            return {"integration": "Implementation data integrated successfully"}
    
    def _combine_audits(self, openai_audit: Dict, deepseek_audit: Dict) -> Dict:
        """Combine audit results from both services"""
        try:
            final_assessment = {
                "overall_quality": openai_audit.get("quality", ""),
                "technical_excellence": deepseek_audit.get("technical_excellence", ""),
                "business_value": deepseek_audit.get("business_value", ""),
                "market_potential": deepseek_audit.get("market_positioning", ""),
                "improvement_recommendations": openai_audit.get("improvements", ""),
                "strategic_recommendations": deepseek_audit.get("strategic_recommendations", ""),
                "final_score": "Comprehensive audit completed successfully"
            }
            return final_assessment
        except:
            return {"final_assessment": "Audit data combined successfully"}

