import openai
import os
from typing import Dict, List, Optional
import json

class OpenAIService:
    def __init__(self, api_key: str):
        self.client = openai.OpenAI(api_key=api_key)
        
    def generate_text(self, prompt: str, model: str = "gpt-3.5-turbo", max_tokens: int = 1000, temperature: float = 0.7) -> str:
        """Generate text using OpenAI's GPT models"""
        try:
            response = self.client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                max_tokens=max_tokens,
                temperature=temperature
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"Error generating text: {str(e)}"
    
    def analyze_project_requirements(self, title: str, description: str) -> Dict:
        """Analyze project requirements and generate comprehensive analysis"""
        prompt = f"""
        As an expert project analyst, analyze the following project request and provide a comprehensive analysis:
        
        Project Title: {title}
        Project Description: {description}
        
        Please provide a detailed analysis including:
        1. Project scope and objectives
        2. Key requirements and features
        3. Technical specifications
        4. Recommended technology stack
        5. Implementation timeline
        6. Potential challenges and solutions
        7. Success metrics
        
        Format your response as a structured JSON with the following keys:
        - scope
        - requirements
        - technical_specs
        - tech_stack
        - timeline
        - challenges
        - success_metrics
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=2000, temperature=0.3)
            # Try to parse as JSON, fallback to structured text if parsing fails
            try:
                return json.loads(response)
            except:
                return {"analysis": response}
        except Exception as e:
            return {"error": f"Analysis failed: {str(e)}"}
    
    def generate_project_code(self, analysis: Dict, project_type: str = "web") -> Dict:
        """Generate project code based on analysis"""
        prompt = f"""
        As an expert software developer, generate code for the following project based on the analysis:
        
        Analysis: {json.dumps(analysis, indent=2)}
        Project Type: {project_type}
        
        Please generate:
        1. Project structure
        2. Main application files
        3. Configuration files
        4. Documentation
        5. Installation instructions
        
        Provide practical, working code that can be implemented immediately.
        Format as JSON with keys: structure, main_files, config, documentation, installation
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=3000, temperature=0.2)
            try:
                return json.loads(response)
            except:
                return {"code": response}
        except Exception as e:
            return {"error": f"Code generation failed: {str(e)}"}
    
    def audit_project(self, project_data: Dict) -> Dict:
        """Audit project for quality, performance, and improvements"""
        prompt = f"""
        As an expert project auditor, review the following project and provide a comprehensive audit:
        
        Project Data: {json.dumps(project_data, indent=2)}
        
        Please provide:
        1. Quality assessment
        2. Performance analysis
        3. Security review
        4. Code quality metrics
        5. Improvement recommendations
        6. Best practices compliance
        7. Market analysis
        8. User experience evaluation
        
        Format as JSON with keys: quality, performance, security, improvements, market_analysis, ux_evaluation
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=2000, temperature=0.3)
            try:
                return json.loads(response)
            except:
                return {"audit": response}
        except Exception as e:
            return {"error": f"Audit failed: {str(e)}"}
    
    def coordinate_workflow(self, project_title: str, current_status: str, bot_statuses: Dict) -> Dict:
        """Coordinate workflow and provide next steps"""
        prompt = f"""
        As a project coordinator, manage the workflow for the following project:
        
        Project: {project_title}
        Current Status: {current_status}
        Bot Statuses: {json.dumps(bot_statuses, indent=2)}
        
        Provide coordination instructions including:
        1. Next steps
        2. Priority tasks
        3. Resource allocation
        4. Timeline adjustments
        5. Risk mitigation
        
        Format as JSON with keys: next_steps, priorities, resources, timeline, risks
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=1500, temperature=0.4)
            try:
                return json.loads(response)
            except:
                return {"coordination": response}
        except Exception as e:
            return {"error": f"Coordination failed: {str(e)}"}

