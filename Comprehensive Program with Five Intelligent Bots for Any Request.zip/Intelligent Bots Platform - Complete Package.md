# Intelligent Bots Platform - Complete Package

## 🚀 Overview

This is a comprehensive AI-powered project building platform featuring five intelligent bots that work together to handle any user request through a coordinated workflow. The platform includes both web and mobile applications connected to an AI-powered backend.

## 🤖 Five Intelligent Bots

1. **Coordinator Bot** - Manages user interaction and orchestrates the entire workflow
2. **Research Bot** - Performs deep search across all available sources worldwide using AI
3. **Analysis Bot** - Analyzes research data and creates comprehensive project plans using AI
4. **Builder Bot** - Builds the complete project from A to Z based on analysis using AI
5. **Audit Bot** - Audits final product and provides improvement recommendations using AI

## 📦 Package Contents

```
intelligent-bots-complete/
├── web-application/          # React web application
├── mobile-application/       # React mobile-optimized application
├── backend/                  # Flask AI-powered backend
├── documentation/           # System architecture and documentation
├── README.md               # This file
└── SETUP.md               # Detailed setup instructions
```

## 🔧 Technology Stack

### Frontend (Web & Mobile)
- **React 18** with Vite
- **Tailwind CSS** for styling
- **shadcn/ui** components
- **Lucide React** icons
- **Framer Motion** for animations

### Backend
- **Flask** with Python 3.11
- **SQLAlchemy** for database
- **Flask-CORS** for cross-origin requests
- **OpenAI API** integration
- **DeepSeek API** integration

### AI Integration
- **OpenAI GPT** for advanced AI capabilities
- **DeepSeek** for additional AI processing
- Real-time bot coordination and workflow management

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ and pnpm
- Python 3.11+
- OpenAI API key
- DeepSeek API key

### 1. Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# Set environment variables
export OPENAI_API_KEY="your-openai-key"
export DEEPSEEK_API_KEY="your-deepseek-key"

python src/main.py
```

### 2. Web Application Setup
```bash
cd web-application
pnpm install
pnpm run dev --host
```

### 3. Mobile Application Setup
```bash
cd mobile-application
pnpm install
pnpm run dev --host --port 5174
```

## 🌐 Access URLs

- **Backend API**: http://localhost:5001
- **Web Application**: http://localhost:5173
- **Mobile Application**: http://localhost:5174

## 📱 Features

### Web Application
- Elegant desktop interface with tabbed navigation
- Real-time bot status monitoring
- Comprehensive project request forms
- Advanced workflow visualization
- Responsive design for all screen sizes

### Mobile Application
- Mobile-first design with touch-friendly interface
- Bottom navigation for easy thumb access
- Optimized forms for mobile input
- Real-time AI bot monitoring
- Progressive Web App (PWA) capabilities

### AI-Powered Backend
- Five coordinated AI bots with distinct roles
- OpenAI and DeepSeek integration
- Real-time status updates and progress tracking
- RESTful API for frontend communication
- Comprehensive project management system

## 🔑 API Keys Configuration

The application requires two API keys:

1. **OpenAI API Key**: Used for advanced AI capabilities in all bots
2. **DeepSeek API Key**: Used for additional AI processing and analysis

### Setting API Keys

#### Method 1: Environment Variables
```bash
export OPENAI_API_KEY="sk-proj-your-openai-key"
export DEEPSEEK_API_KEY="sk-your-deepseek-key"
```

#### Method 2: Backend Configuration
Edit `backend/src/services/openai_service.py` and `backend/src/services/deepseek_service.py` to include your keys directly.

## 📊 Bot Workflow

1. **User submits project request** through web or mobile interface
2. **Coordinator Bot** receives and validates the request
3. **Research Bot** performs deep AI-powered research on the topic
4. **Analysis Bot** analyzes research data and creates project plans
5. **Builder Bot** builds the complete project based on analysis
6. **Audit Bot** reviews and provides improvement recommendations
7. **Final results** are delivered to the user

## 🛠️ Development

### Adding New Features
- Frontend components are in `src/components/`
- Backend routes are in `src/routes/`
- AI services are in `src/services/`

### Database
- SQLite database is automatically created
- Models are defined in `src/models/`

### Testing
- Both applications include development servers with hot reload
- Backend includes health check endpoints
- AI integration can be tested via `/api/ai/status`

## 📚 Documentation

- `system_architecture.md` - Detailed system architecture
- `PROJECT_SUMMARY.md` - Project completion summary
- `todo.md` - Development progress tracking

## 🔒 Security Notes

- API keys should be kept secure and not committed to version control
- The backend includes CORS configuration for development
- For production deployment, additional security measures should be implemented

## 🚀 Deployment

### Web Application
```bash
cd web-application
pnpm run build
# Deploy the dist/ folder to your hosting service
```

### Mobile Application
```bash
cd mobile-application
pnpm run build
# Deploy as Progressive Web App (PWA)
```

### Backend
```bash
cd backend
# Use a production WSGI server like Gunicorn
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5001 src.main:app
```

## 📞 Support

For questions or issues:
1. Check the documentation in the `documentation/` folder
2. Review the system architecture diagram
3. Ensure all API keys are properly configured
4. Verify all dependencies are installed

## 🎯 Key Features Delivered

✅ Five intelligent AI-powered bots with distinct roles
✅ Elegant web interface with modern design
✅ Mobile-optimized application with touch-friendly UI
✅ Real-time AI integration with OpenAI and DeepSeek
✅ Comprehensive project workflow management
✅ Cross-platform compatibility
✅ Complete source code with documentation
✅ Easy setup and deployment instructions

---

**Built with ❤️ using modern web technologies and AI integration**

