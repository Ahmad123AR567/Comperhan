# Detailed Setup Instructions

## 📋 Prerequisites

Before setting up the Intelligent Bots Platform, ensure you have the following installed:

### Required Software
- **Node.js 20+** - [Download from nodejs.org](https://nodejs.org/)
- **pnpm** - Install with `npm install -g pnpm`
- **Python 3.11+** - [Download from python.org](https://python.org/)
- **Git** - [Download from git-scm.com](https://git-scm.com/)

### Required API Keys
- **OpenAI API Key** - Get from [OpenAI Platform](https://platform.openai.com/)
- **DeepSeek API Key** - Get from [DeepSeek Platform](https://platform.deepseek.com/)

## 🔧 Step-by-Step Setup

### Step 1: Extract the Package
```bash
unzip intelligent-bots-complete.zip
cd intelligent-bots-complete
```

### Step 2: Backend Setup

1. **Navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   ```

3. **Activate virtual environment**
   - On Linux/Mac: `source venv/bin/activate`
   - On Windows: `venv\Scripts\activate`

4. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

5. **Configure API keys**
   
   **Option A: Environment Variables (Recommended)**
   ```bash
   export OPENAI_API_KEY="sk-proj-your-openai-key-here"
   export DEEPSEEK_API_KEY="sk-your-deepseek-key-here"
   ```
   
   **Option B: Direct Configuration**
   - Edit `src/services/openai_service.py` line 8
   - Edit `src/services/deepseek_service.py` line 8
   - Replace the API key placeholders with your actual keys

6. **Start the backend server**
   ```bash
   python src/main.py
   ```
   
   You should see:
   ```
   * Running on http://127.0.0.1:5001
   * Running on http://169.254.0.21:5001
   ```

7. **Verify backend is working**
   - Open browser to `http://localhost:5001/health`
   - Should show: `{"message": "Intelligent Bots Backend is running", "status": "healthy"}`

### Step 3: Web Application Setup

1. **Open new terminal and navigate to web application**
   ```bash
   cd web-application
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Start development server**
   ```bash
   pnpm run dev --host
   ```
   
   You should see:
   ```
   ➜  Local:   http://localhost:5173/
   ➜  Network: http://169.254.0.21:5173/
   ```

4. **Verify web application**
   - Open browser to `http://localhost:5173`
   - Should see the Intelligent Bots Platform interface

### Step 4: Mobile Application Setup

1. **Open new terminal and navigate to mobile application**
   ```bash
   cd mobile-application
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Start development server**
   ```bash
   pnpm run dev --host --port 5174
   ```
   
   You should see:
   ```
   ➜  Local:   http://localhost:5174/
   ➜  Network: http://169.254.0.21:5174/
   ```

4. **Verify mobile application**
   - Open browser to `http://localhost:5174`
   - Should see the mobile-optimized interface

## 🧪 Testing the Complete System

### 1. Test Backend AI Integration
```bash
curl http://localhost:5001/api/ai/status
```
Should return:
```json
{
  "ai_coordinator_active": true,
  "deepseek_enabled": true,
  "openai_enabled": true,
  "services": {
    "coordinator": "AI coordination active",
    "deepseek": "Connected and operational",
    "openai": "Connected and operational"
  }
}
```

### 2. Test Web Application
1. Go to `http://localhost:5173`
2. Click "New Request" tab
3. Enter a project title and description
4. Click "Submit Request"
5. Go to "Dashboard" to see bots working

### 3. Test Mobile Application
1. Go to `http://localhost:5174`
2. Tap "New Request" in bottom navigation
3. Enter a project title and description
4. Tap "Submit Request"
5. Tap "Dashboard" to see bots working

## 🚨 Troubleshooting

### Backend Issues

**Port 5001 already in use**
```bash
# Kill existing process
lsof -ti:5001 | xargs kill -9
# Or change port in src/main.py line 51
```

**API Keys not working**
- Verify keys are correctly set in environment variables
- Check that keys have proper permissions
- Ensure no extra spaces or quotes in key values

**Database errors**
```bash
# Delete and recreate database
rm src/database/app.db
python src/main.py
```

### Frontend Issues

**Dependencies installation fails**
```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

**Port conflicts**
```bash
# Use different ports
pnpm run dev --host --port 3000  # For web app
pnpm run dev --host --port 3001  # For mobile app
```

**Backend connection fails**
- Ensure backend is running on port 5001
- Check CORS configuration in backend
- Verify API_BASE_URL in App.jsx files

## 🔄 Development Workflow

### Making Changes

1. **Backend changes**: Edit files in `backend/src/`, server auto-reloads
2. **Frontend changes**: Edit files in `src/`, browser auto-refreshes
3. **Database changes**: Modify models in `backend/src/models/`

### Adding New Features

1. **New bot functionality**: Add to `backend/src/services/ai_coordinator.py`
2. **New UI components**: Add to `src/components/`
3. **New API endpoints**: Add to `backend/src/routes/`

## 📦 Production Deployment

### Backend Deployment
```bash
cd backend
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5001 src.main:app
```

### Frontend Deployment
```bash
cd web-application
pnpm run build
# Deploy dist/ folder to hosting service

cd mobile-application
pnpm run build
# Deploy dist/ folder as PWA
```

## 🔐 Security Considerations

1. **Never commit API keys** to version control
2. **Use environment variables** for sensitive data
3. **Enable HTTPS** in production
4. **Implement rate limiting** for API endpoints
5. **Validate all user inputs** on backend

## 📊 Monitoring

### Health Checks
- Backend: `http://localhost:5001/health`
- AI Status: `http://localhost:5001/api/ai/status`
- Bot Config: `http://localhost:5001/api/bots/config`

### Logs
- Backend logs appear in terminal where server is running
- Frontend logs appear in browser developer console

## 🎯 Success Criteria

✅ Backend server starts without errors
✅ Web application loads and connects to backend
✅ Mobile application loads and connects to backend
✅ AI status endpoint shows all services operational
✅ Can submit projects through both interfaces
✅ Bots show real-time status updates

---

**Need help?** Check the documentation folder for additional resources!

