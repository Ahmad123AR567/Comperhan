import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Bot, 
  Search, 
  BarChart3, 
  Wrench, 
  Shield, 
  Send, 
  Sparkles,
  Clock,
  CheckCircle,
  AlertCircle,
  Play,
  Pause
} from 'lucide-react'
import './App.css'
const API_BASE_URL = 'http://localhost:5001/api';

function App() {
  const [projectRequest, setProjectRequest] = useState('')
  const [projectDescription, setProjectDescription] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentProject, setCurrentProject] = useState(null)
  const [botConfigs, setBotConfigs] = useState({})
  const [botStatuses, setBotStatuses] = useState({})
  const [projects, setProjects] = useState([])

  const bots = [
    {
      id: 'coordinator',
      name: 'Coordinator Bot',
      icon: Bot,
      color: 'bg-blue-500',
      description: 'Manages user interaction and orchestrates the entire workflow'
    },
    {
      id: 'research',
      name: 'Research Bot',
      icon: Search,
      color: 'bg-green-500',
      description: 'Performs deep search across all available sources worldwide'
    },
    {
      id: 'analysis',
      name: 'Analysis Bot',
      icon: BarChart3,
      color: 'bg-purple-500',
      description: 'Analyzes research data and creates comprehensive project plans'
    },
    {
      id: 'builder',
      name: 'Builder Bot',
      icon: Wrench,
      color: 'bg-orange-500',
      description: 'Builds the complete project from A to Z based on analysis'
    },
    {
      id: 'audit',
      name: 'Audit Bot',
      icon: Shield,
      color: 'bg-red-500',
      description: 'Audits final product and provides improvement recommendations'
    }
  ]

  // Load bot configurations on component mount
  useEffect(() => {
    fetchBotConfigs()
    fetchProjects()
  }, [])

  // Poll for project status updates when processing
  useEffect(() => {
    let interval
    if (isProcessing && currentProject) {
      interval = setInterval(() => {
        fetchProjectStatus(currentProject.id)
      }, 2000) // Poll every 2 seconds
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isProcessing, currentProject])

  const fetchBotConfigs = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/bots/config`)
      const configs = await response.json()
      setBotConfigs(configs)
    } catch (error) {
      console.error('Error fetching bot configs:', error)
    }
  }

  const fetchProjects = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/projects`)
      const projectsData = await response.json()
      setProjects(projectsData)
    } catch (error) {
      console.error('Error fetching projects:', error)
    }
  }

  const fetchProjectStatus = async (projectId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/projects/${projectId}/status`)
      const statusData = await response.json()
      
      setBotStatuses(statusData.bot_statuses)
      
      // Check if project is completed
      if (statusData.project_status === 'completed' || statusData.project_status === 'failed') {
        setIsProcessing(false)
        fetchProjects() // Refresh projects list
      }
    } catch (error) {
      console.error('Error fetching project status:', error)
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <Play className="w-4 h-4 text-green-500" />
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'error': return <AlertCircle className="w-4 h-4 text-red-500" />
      case 'paused': return <Pause className="w-4 h-4 text-yellow-500" />
      default: return <Clock className="w-4 h-4 text-gray-400" />
    }
  }

  const getCurrentStep = () => {
    const botOrder = ['coordinator', 'research', 'analysis', 'builder', 'audit']
    let currentStep = 0
    
    for (let i = 0; i < botOrder.length; i++) {
      const botStatus = botStatuses[botOrder[i]]
      if (botStatus && botStatus.status === 'completed') {
        currentStep = i + 1
      } else if (botStatus && botStatus.status === 'active') {
        currentStep = i
        break
      }
    }
    
    return currentStep
  }

  const handleSubmitRequest = async () => {
    if (!projectRequest.trim()) return
    
    try {
      setIsProcessing(true)
      
      const response = await fetch(`${API_BASE_URL}/projects`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: projectRequest,
          description: projectDescription
        })
      })
      
      if (response.ok) {
        const result = await response.json()
        setCurrentProject(result.project)
        
        // Initialize bot statuses
        const initialStatuses = {}
        bots.forEach(bot => {
          initialStatuses[bot.id] = {
            status: 'idle',
            progress: 0,
            message: `Ready to start ${bot.name} tasks`
          }
        })
        setBotStatuses(initialStatuses)
        
      } else {
        console.error('Error creating project:', response.statusText)
        setIsProcessing(false)
      }
    } catch (error) {
      console.error('Error submitting request:', error)
      setIsProcessing(false)
    }
  }

  const resetWorkflow = () => {
    setIsProcessing(false)
    setCurrentProject(null)
    setBotStatuses({})
    setProjectRequest('')
    setProjectDescription('')
  }

  const currentStep = getCurrentStep()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Intelligent Bots Platform
                </h1>
                <p className="text-sm text-muted-foreground">AI-Powered Project Builder</p>
              </div>
            </div>
            <Badge variant="outline" className="px-3 py-1">
              5 AI Bots Active
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="request">New Request</TabsTrigger>
            <TabsTrigger value="bots">Bot Status</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bots.map((bot) => {
                const status = botStatuses[bot.id] || { status: 'idle', progress: 0, message: `Ready to start ${bot.name} tasks` }
                return (
                  <Card key={bot.id} className="relative overflow-hidden group hover:shadow-lg transition-all duration-300">
                    <div className={`absolute top-0 left-0 w-full h-1 ${bot.color}`} />
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 ${bot.color} rounded-lg`}>
                            <bot.icon className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{bot.name}</CardTitle>
                            <div className="flex items-center space-x-2 mt-1">
                              {getStatusIcon(status.status)}
                              <Badge variant={status.status === 'completed' ? 'default' : 'secondary'}>
                                {status.status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground mb-3">{bot.description}</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{status.progress}%</span>
                        </div>
                        <Progress value={status.progress} className="h-2" />
                        <p className="text-xs text-muted-foreground">{status.message}</p>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Workflow Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Workflow Progress</CardTitle>
                <CardDescription>Current project processing status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  {bots.map((bot, index) => (
                    <div key={bot.id} className="flex flex-col items-center space-y-2">
                      <div className={`p-3 rounded-full ${
                        currentStep > index ? 'bg-green-500' : 
                        currentStep === index ? bot.color : 'bg-gray-200 dark:bg-gray-700'
                      } transition-all duration-300`}>
                        <bot.icon className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-xs text-center max-w-16">{bot.name.split(' ')[0]}</span>
                      {index < bots.length - 1 && (
                        <div className={`w-8 h-0.5 ${
                          currentStep > index ? 'bg-green-500' : 'bg-gray-200 dark:bg-gray-700'
                        } transition-all duration-300`} />
                      )}
                    </div>
                  ))}
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">
                    {isProcessing ? 'Processing your request...' : 'Ready to process new requests'}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Recent Projects */}
            {projects.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Recent Projects</CardTitle>
                  <CardDescription>Your latest project submissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {projects.slice(0, 5).map((project) => (
                      <div key={project.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <h4 className="font-medium">{project.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            Created: {new Date(project.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={
                          project.status === 'completed' ? 'default' :
                          project.status === 'processing' ? 'secondary' :
                          project.status === 'failed' ? 'destructive' : 'outline'
                        }>
                          {project.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Request Tab */}
          <TabsContent value="request" className="space-y-6">
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Send className="w-5 h-5" />
                  <span>Submit New Project Request</span>
                </CardTitle>
                <CardDescription>
                  Describe your project and let our intelligent bots build it for you
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Project Title</label>
                  <Input
                    placeholder="Enter your project title..."
                    value={projectRequest}
                    onChange={(e) => setProjectRequest(e.target.value)}
                    className="w-full"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Project Description</label>
                  <Textarea
                    placeholder="Provide detailed description of what you want to build..."
                    value={projectDescription}
                    onChange={(e) => setProjectDescription(e.target.value)}
                    className="w-full min-h-32"
                  />
                </div>

                <div className="flex space-x-3">
                  <Button 
                    onClick={handleSubmitRequest}
                    disabled={!projectRequest.trim() || isProcessing}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Submit Request
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={resetWorkflow}
                    disabled={isProcessing}
                  >
                    Reset
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bot Status Tab */}
          <TabsContent value="bots" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {bots.map((bot) => {
                const status = botStatuses[bot.id] || { status: 'idle', progress: 0, message: `Ready to start ${bot.name} tasks` }
                return (
                  <Card key={bot.id} className="relative">
                    <div className={`absolute top-0 left-0 w-full h-2 ${bot.color}`} />
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className={`p-3 ${bot.color} rounded-lg`}>
                          <bot.icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="flex items-center justify-between">
                            {bot.name}
                            {getStatusIcon(status.status)}
                          </CardTitle>
                          <CardDescription>{bot.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Current Progress</span>
                          <span>{status.progress}%</span>
                        </div>
                        <Progress value={status.progress} className="h-3" />
                      </div>
                      
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm">{status.message}</p>
                      </div>
                      
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Status: {status.status}</span>
                        <Badge variant="outline">
                          {status.status === 'active' ? 'Working' : 
                           status.status === 'completed' ? 'Done' : 'Idle'}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

