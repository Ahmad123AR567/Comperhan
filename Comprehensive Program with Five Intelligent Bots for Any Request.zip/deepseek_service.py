import requests
import json
from typing import Dict, List, Optional

class DeepSeekService:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.deepseek.com/v1"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def generate_text(self, prompt: str, model: str = "deepseek-chat", max_tokens: int = 1000, temperature: float = 0.7) -> str:
        """Generate text using DeepSeek's models"""
        try:
            payload = {
                "model": model,
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "max_tokens": max_tokens,
                "temperature": temperature
            }
            
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"].strip()
            else:
                return f"Error: {response.status_code} - {response.text}"
                
        except Exception as e:
            return f"Error generating text: {str(e)}"
    
    def research_project(self, title: str, description: str) -> Dict:
        """Research project using DeepSeek's capabilities"""
        prompt = f"""
        As an expert researcher, conduct comprehensive research for the following project:
        
        Project Title: {title}
        Project Description: {description}
        
        Please provide detailed research including:
        1. Market analysis and trends
        2. Competitor analysis
        3. Technology landscape
        4. Best practices and standards
        5. Industry insights
        6. User needs and preferences
        7. Implementation strategies
        8. Resource requirements
        
        Format your response as structured JSON with keys:
        - market_analysis
        - competitors
        - technology_landscape
        - best_practices
        - industry_insights
        - user_needs
        - implementation_strategies
        - resources
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=2500, temperature=0.3)
            try:
                return json.loads(response)
            except:
                return {"research": response}
        except Exception as e:
            return {"error": f"Research failed: {str(e)}"}
    
    def deep_analysis(self, research_data: Dict, project_info: Dict) -> Dict:
        """Perform deep analysis using DeepSeek's advanced capabilities"""
        prompt = f"""
        As an expert data analyst, perform deep analysis on the following research data:
        
        Research Data: {json.dumps(research_data, indent=2)}
        Project Info: {json.dumps(project_info, indent=2)}
        
        Provide comprehensive analysis including:
        1. Data synthesis and insights
        2. Pattern recognition
        3. Trend analysis
        4. Risk assessment
        5. Opportunity identification
        6. Strategic recommendations
        7. Implementation roadmap
        8. Success probability
        
        Format as JSON with keys: insights, patterns, trends, risks, opportunities, recommendations, roadmap, success_probability
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=2000, temperature=0.2)
            try:
                return json.loads(response)
            except:
                return {"analysis": response}
        except Exception as e:
            return {"error": f"Deep analysis failed: {str(e)}"}
    
    def generate_advanced_code(self, specifications: Dict) -> Dict:
        """Generate advanced code using DeepSeek's coding capabilities"""
        prompt = f"""
        As an expert software architect and developer, generate advanced code based on these specifications:
        
        Specifications: {json.dumps(specifications, indent=2)}
        
        Generate:
        1. Advanced architecture design
        2. Optimized code implementation
        3. Performance enhancements
        4. Security implementations
        5. Scalability solutions
        6. Testing strategies
        7. Deployment configurations
        8. Monitoring and logging
        
        Provide production-ready, enterprise-level code.
        Format as JSON with keys: architecture, implementation, performance, security, scalability, testing, deployment, monitoring
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=3500, temperature=0.1)
            try:
                return json.loads(response)
            except:
                return {"code": response}
        except Exception as e:
            return {"error": f"Advanced code generation failed: {str(e)}"}
    
    def comprehensive_audit(self, project_data: Dict) -> Dict:
        """Perform comprehensive audit using DeepSeek's analytical capabilities"""
        prompt = f"""
        As an expert auditor and consultant, perform a comprehensive audit of this project:
        
        Project Data: {json.dumps(project_data, indent=2)}
        
        Provide detailed audit covering:
        1. Technical excellence assessment
        2. Business value analysis
        3. Market positioning evaluation
        4. Competitive advantage assessment
        5. Scalability and maintainability review
        6. Innovation and uniqueness analysis
        7. ROI and financial projections
        8. Strategic recommendations
        
        Format as JSON with keys: technical_excellence, business_value, market_positioning, competitive_advantage, scalability, innovation, financial_projections, strategic_recommendations
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=2500, temperature=0.3)
            try:
                return json.loads(response)
            except:
                return {"audit": response}
        except Exception as e:
            return {"error": f"Comprehensive audit failed: {str(e)}"}
    
    def search_and_analyze(self, query: str, context: str = "") -> Dict:
        """Search and analyze information using DeepSeek's capabilities"""
        prompt = f"""
        As an expert researcher and analyst, search and analyze information about:
        
        Query: {query}
        Context: {context}
        
        Provide:
        1. Comprehensive information gathering
        2. Source analysis and verification
        3. Data synthesis
        4. Key insights extraction
        5. Trend identification
        6. Actionable recommendations
        
        Format as JSON with keys: information, sources, synthesis, insights, trends, recommendations
        """
        
        try:
            response = self.generate_text(prompt, max_tokens=2000, temperature=0.4)
            try:
                return json.loads(response)
            except:
                return {"search_analysis": response}
        except Exception as e:
            return {"error": f"Search and analysis failed: {str(e)}"}

