from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return f'<User {self.username}>'

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email
        }

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), default='pending')  # pending, processing, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    result_data = db.Column(db.Text)  # JSON string for storing results
    
    # Relationships
    bot_statuses = db.relationship('BotStatus', backref='project', lazy=True, cascade='all, delete-orphan')
    workflow_logs = db.relationship('WorkflowLog', backref='project', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Project {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'result_data': json.loads(self.result_data) if self.result_data else None,
            'bot_statuses': [bot.to_dict() for bot in self.bot_statuses],
            'workflow_logs': [log.to_dict() for log in self.workflow_logs]
        }

class BotStatus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    bot_name = db.Column(db.String(50), nullable=False)  # coordinator, research, analysis, builder, audit
    status = db.Column(db.String(50), default='idle')  # idle, active, completed, error, paused
    progress = db.Column(db.Integer, default=0)  # 0-100
    message = db.Column(db.String(500))
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    data = db.Column(db.Text)  # JSON string for bot-specific data

    def __repr__(self):
        return f'<BotStatus {self.bot_name} - {self.status}>'

    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,
            'bot_name': self.bot_name,
            'status': self.status,
            'progress': self.progress,
            'message': self.message,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'data': json.loads(self.data) if self.data else None
        }

class WorkflowLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    bot_name = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    message = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    data = db.Column(db.Text)  # JSON string for additional data

    def __repr__(self):
        return f'<WorkflowLog {self.bot_name} - {self.action}>'

    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,
            'bot_name': self.bot_name,
            'action': self.action,
            'message': self.message,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'data': json.loads(self.data) if self.data else None
        }

