from flask import Blueprint, request, jsonify
from src.models.user import db, Project, BotStatus, WorkflowLog
from src.services.ai_coordinator import AICoordinator
import threading
import time
import json
from datetime import datetime

bots_bp = Blueprint('bots', __name__)

# Initialize AI Coordinator with API keys
OPENAI_API_KEY = "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"
DEEPSEEK_API_KEY = "sk-44145c9ed58b4bb5b36d95d707bd67a4"

ai_coordinator = AICoordinator(OPENAI_API_KEY, DEEPSEEK_API_KEY)

# Bot configuration
BOT_CONFIGS = {
    'coordinator': {
        'name': 'Coordinator Bot',
        'description': 'Manages user interaction and orchestrates the entire workflow using AI',
        'color': 'bg-blue-500'
    },
    'research': {
        'name': 'Research Bot',
        'description': 'Performs deep AI-powered search across all available sources worldwide',
        'color': 'bg-green-500'
    },
    'analysis': {
        'name': 'Analysis Bot',
        'description': 'Uses AI to analyze research data and create comprehensive project plans',
        'color': 'bg-purple-500'
    },
    'builder': {
        'name': 'Builder Bot',
        'description': 'Uses AI to build complete projects from A to Z based on analysis',
        'color': 'bg-orange-500'
    },
    'audit': {
        'name': 'Audit Bot',
        'description': 'Uses AI to audit final products and provide improvement recommendations',
        'color': 'bg-red-500'
    }
}

def create_bot_statuses(project_id):
    """Create initial bot status records for a new project"""
    for bot_name, config in BOT_CONFIGS.items():
        bot_status = BotStatus(
            project_id=project_id,
            bot_name=bot_name,
            status='idle',
            progress=0,
            message=f"Ready to start {config['name']} AI-powered tasks"
        )
        db.session.add(bot_status)
    db.session.commit()

def log_workflow_action(project_id, bot_name, action, message, data=None):
    """Log a workflow action"""
    log = WorkflowLog(
        project_id=project_id,
        bot_name=bot_name,
        action=action,
        message=message,
        data=json.dumps(data) if data else None
    )
    db.session.add(log)
    db.session.commit()

def update_bot_status(project_id, bot_name, status, progress, message, data=None):
    """Update bot status"""
    bot_status = BotStatus.query.filter_by(project_id=project_id, bot_name=bot_name).first()
    if bot_status:
        bot_status.status = status
        bot_status.progress = progress
        bot_status.message = message
        if data:
            bot_status.data = json.dumps(data)
        
        if status == 'active' and not bot_status.started_at:
            bot_status.started_at = datetime.utcnow()
        elif status == 'completed':
            bot_status.completed_at = datetime.utcnow()
        
        db.session.commit()

def coordinator_bot_work(project_id, project_title, project_description):
    """Coordinator Bot AI-powered work"""
    try:
        update_bot_status(project_id, 'coordinator', 'active', 10, 'Initializing AI-powered project coordination...')
        log_workflow_action(project_id, 'coordinator', 'started', 'Coordinator Bot began AI processing')
        
        # Get current bot statuses
        bot_statuses = {}
        statuses = BotStatus.query.filter_by(project_id=project_id).all()
        for status in statuses:
            bot_statuses[status.bot_name] = {
                'status': status.status,
                'progress': status.progress,
                'message': status.message
            }
        
        update_bot_status(project_id, 'coordinator', 'active', 50, 'AI analyzing project workflow and coordination strategy...')
        
        # Use AI to coordinate workflow
        coordination_result = ai_coordinator.coordinate_workflow(project_title, 'initializing', bot_statuses)
        
        update_bot_status(project_id, 'coordinator', 'active', 90, 'AI coordination strategy completed, preparing workflow...')
        
        # Store coordination data
        update_bot_status(project_id, 'coordinator', 'completed', 100, 'AI-powered coordination completed successfully!', coordination_result)
        log_workflow_action(project_id, 'coordinator', 'completed', 'Coordinator Bot finished AI processing', coordination_result)
        
    except Exception as e:
        update_bot_status(project_id, 'coordinator', 'error', 0, f'AI coordination error: {str(e)}')
        log_workflow_action(project_id, 'coordinator', 'error', f'Error occurred: {str(e)}')

def research_bot_work(project_id, project_title, project_description):
    """Research Bot AI-powered work"""
    try:
        update_bot_status(project_id, 'research', 'active', 10, 'Starting AI-powered deep research across global sources...')
        log_workflow_action(project_id, 'research', 'started', 'Research Bot began AI-powered research')
        
        update_bot_status(project_id, 'research', 'active', 30, 'AI analyzing market trends and competitive landscape...')
        
        # Use AI to perform comprehensive research
        research_result = ai_coordinator.coordinate_research(project_title, project_description)
        
        update_bot_status(project_id, 'research', 'active', 70, 'AI processing research data and extracting insights...')
        
        update_bot_status(project_id, 'research', 'active', 90, 'AI finalizing comprehensive research report...')
        
        # Store research data
        update_bot_status(project_id, 'research', 'completed', 100, 'AI-powered research completed successfully!', research_result)
        log_workflow_action(project_id, 'research', 'completed', 'Research Bot finished AI processing', research_result)
        
    except Exception as e:
        update_bot_status(project_id, 'research', 'error', 0, f'AI research error: {str(e)}')
        log_workflow_action(project_id, 'research', 'error', f'Error occurred: {str(e)}')

def analysis_bot_work(project_id, project_title, project_description):
    """Analysis Bot AI-powered work"""
    try:
        update_bot_status(project_id, 'analysis', 'active', 10, 'Starting AI-powered data analysis and synthesis...')
        log_workflow_action(project_id, 'analysis', 'started', 'Analysis Bot began AI processing')
        
        # Get research data
        research_bot = BotStatus.query.filter_by(project_id=project_id, bot_name='research').first()
        research_data = json.loads(research_bot.data) if research_bot and research_bot.data else {}
        
        project_info = {
            'title': project_title,
            'description': project_description
        }
        
        update_bot_status(project_id, 'analysis', 'active', 40, 'AI analyzing research data and identifying patterns...')
        
        # Use AI to perform comprehensive analysis
        analysis_result = ai_coordinator.coordinate_analysis(research_data, project_info)
        
        update_bot_status(project_id, 'analysis', 'active', 80, 'AI creating comprehensive project blueprint...')
        
        # Store analysis data
        update_bot_status(project_id, 'analysis', 'completed', 100, 'AI-powered analysis completed successfully!', analysis_result)
        log_workflow_action(project_id, 'analysis', 'completed', 'Analysis Bot finished AI processing', analysis_result)
        
    except Exception as e:
        update_bot_status(project_id, 'analysis', 'error', 0, f'AI analysis error: {str(e)}')
        log_workflow_action(project_id, 'analysis', 'error', f'Error occurred: {str(e)}')

def builder_bot_work(project_id, project_title, project_description):
    """Builder Bot AI-powered work"""
    try:
        update_bot_status(project_id, 'builder', 'active', 10, 'Starting AI-powered project building from A to Z...')
        log_workflow_action(project_id, 'builder', 'started', 'Builder Bot began AI processing')
        
        # Get analysis data
        analysis_bot = BotStatus.query.filter_by(project_id=project_id, bot_name='analysis').first()
        analysis_data = json.loads(analysis_bot.data) if analysis_bot and analysis_bot.data else {}
        
        update_bot_status(project_id, 'builder', 'active', 30, 'AI designing project architecture and structure...')
        
        update_bot_status(project_id, 'builder', 'active', 60, 'AI generating code and implementing features...')
        
        # Use AI to build the project
        build_result = ai_coordinator.coordinate_building(analysis_data)
        
        update_bot_status(project_id, 'builder', 'active', 90, 'AI finalizing project implementation and testing...')
        
        # Store build data
        update_bot_status(project_id, 'builder', 'completed', 100, 'AI-powered project building completed successfully!', build_result)
        log_workflow_action(project_id, 'builder', 'completed', 'Builder Bot finished AI processing', build_result)
        
    except Exception as e:
        update_bot_status(project_id, 'builder', 'error', 0, f'AI building error: {str(e)}')
        log_workflow_action(project_id, 'builder', 'error', f'Error occurred: {str(e)}')

def audit_bot_work(project_id, project_title, project_description):
    """Audit Bot AI-powered work"""
    try:
        update_bot_status(project_id, 'audit', 'active', 10, 'Starting AI-powered comprehensive project audit...')
        log_workflow_action(project_id, 'audit', 'started', 'Audit Bot began AI processing')
        
        # Get all project data
        project_data = {
            'title': project_title,
            'description': project_description
        }
        
        # Collect data from all bots
        bot_statuses = BotStatus.query.filter_by(project_id=project_id).all()
        for bot in bot_statuses:
            if bot.data:
                project_data[f'{bot.bot_name}_data'] = json.loads(bot.data)
        
        update_bot_status(project_id, 'audit', 'active', 40, 'AI performing quality assurance and performance analysis...')
        
        update_bot_status(project_id, 'audit', 'active', 70, 'AI conducting market analysis and improvement assessment...')
        
        # Use AI to audit the project
        audit_result = ai_coordinator.coordinate_audit(project_data)
        
        update_bot_status(project_id, 'audit', 'active', 90, 'AI generating final audit report and recommendations...')
        
        # Store audit data
        update_bot_status(project_id, 'audit', 'completed', 100, 'AI-powered audit completed successfully!', audit_result)
        log_workflow_action(project_id, 'audit', 'completed', 'Audit Bot finished AI processing', audit_result)
        
    except Exception as e:
        update_bot_status(project_id, 'audit', 'error', 0, f'AI audit error: {str(e)}')
        log_workflow_action(project_id, 'audit', 'error', f'Error occurred: {str(e)}')

def run_ai_workflow(project_id, project_title, project_description):
    """Run the complete AI-powered bot workflow"""
    try:
        # Update project status
        project = Project.query.get(project_id)
        if project:
            project.status = 'processing'
            db.session.commit()
        
        # Run bots in sequence with AI capabilities
        coordinator_bot_work(project_id, project_title, project_description)
        time.sleep(2)  # Brief pause between bots
        
        research_bot_work(project_id, project_title, project_description)
        time.sleep(2)
        
        analysis_bot_work(project_id, project_title, project_description)
        time.sleep(2)
        
        builder_bot_work(project_id, project_title, project_description)
        time.sleep(2)
        
        audit_bot_work(project_id, project_title, project_description)
        
        # Compile final results
        final_results = {
            'message': 'AI-powered project completed successfully!',
            'deliverables': [
                'AI-generated comprehensive research report',
                'AI-created detailed project analysis and blueprint',
                'AI-built complete project implementation',
                'AI-conducted quality audit and improvement recommendations',
                'AI-powered market analysis and strategic insights'
            ],
            'completion_time': datetime.utcnow().isoformat(),
            'ai_powered': True,
            'technologies_used': ['OpenAI GPT', 'DeepSeek AI', 'Advanced AI Coordination']
        }
        
        # Update project status to completed
        if project:
            project.status = 'completed'
            project.result_data = json.dumps(final_results)
            db.session.commit()
        
        log_workflow_action(project_id, 'system', 'workflow_completed', 'All AI-powered bots completed successfully', final_results)
        
    except Exception as e:
        # Update project status to failed
        if project:
            project.status = 'failed'
            db.session.commit()
        log_workflow_action(project_id, 'system', 'workflow_failed', f'AI workflow failed: {str(e)}')

@bots_bp.route('/projects', methods=['POST'])
def create_project():
    """Create a new project and start the AI-powered bot workflow"""
    try:
        data = request.get_json()
        
        if not data or not data.get('title') or not data.get('description'):
            return jsonify({'error': 'Title and description are required'}), 400
        
        # Create new project
        project = Project(
            title=data['title'],
            description=data['description'],
            status='pending'
        )
        db.session.add(project)
        db.session.commit()
        
        # Create bot statuses
        create_bot_statuses(project.id)
        
        # Start AI-powered workflow in background thread
        workflow_thread = threading.Thread(
            target=run_ai_workflow, 
            args=(project.id, project.title, project.description)
        )
        workflow_thread.daemon = True
        workflow_thread.start()
        
        return jsonify({
            'message': 'Project created and AI-powered workflow started',
            'project': project.to_dict(),
            'ai_enabled': True
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bots_bp.route('/projects/<int:project_id>', methods=['GET'])
def get_project(project_id):
    """Get project details with bot statuses"""
    try:
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'error': 'Project not found'}), 404
        
        return jsonify(project.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bots_bp.route('/projects', methods=['GET'])
def get_projects():
    """Get all projects"""
    try:
        projects = Project.query.order_by(Project.created_at.desc()).all()
        return jsonify([project.to_dict() for project in projects]), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bots_bp.route('/projects/<int:project_id>/status', methods=['GET'])
def get_project_status(project_id):
    """Get real-time project status"""
    try:
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'error': 'Project not found'}), 404
        
        bot_statuses = BotStatus.query.filter_by(project_id=project_id).all()
        
        return jsonify({
            'project_status': project.status,
            'bot_statuses': {bot.bot_name: bot.to_dict() for bot in bot_statuses},
            'ai_powered': True
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bots_bp.route('/bots/config', methods=['GET'])
def get_bot_configs():
    """Get bot configurations"""
    return jsonify({
        'configs': BOT_CONFIGS,
        'ai_powered': True,
        'ai_services': ['OpenAI GPT', 'DeepSeek AI']
    }), 200

@bots_bp.route('/ai/status', methods=['GET'])
def get_ai_status():
    """Get AI services status"""
    return jsonify({
        'openai_enabled': True,
        'deepseek_enabled': True,
        'ai_coordinator_active': True,
        'services': {
            'openai': 'Connected and operational',
            'deepseek': 'Connected and operational',
            'coordinator': 'AI coordination active'
        }
    }), 200

